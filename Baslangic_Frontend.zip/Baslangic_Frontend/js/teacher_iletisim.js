// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* MESAJLAR KISMI */

document.addEventListener("DOMContentLoaded", () => {
    const mainContainer = document.getElementById("main-container");

    // Yeni Mesaj Yazma Alanı (Genel)
    const composeContainer = document.createElement("div");
    composeContainer.className = "message-compose-container";

    const composeHeader = document.createElement("h3");
    composeHeader.textContent = "Yeni Mesaj Yaz";
    composeContainer.appendChild(composeHeader);

    // Sınıf Seçimi
    const classField = document.createElement("div");
    classField.className = "compose-field";

    const classLabel = document.createElement("label");
    classLabel.textContent = "Sınıf Seç:";
    classField.appendChild(classLabel);

    const classSelect = document.createElement("select");
    classSelect.id = "class-select";
    ["Tüm Sınıflar", "9-A", "10-B", "11-C"].forEach((optionText, index) => {
        const option = document.createElement("option");
        option.value = index === 0 ? "all" : `class-${index}`;
        option.textContent = optionText;
        classSelect.appendChild(option);
    });
    classField.appendChild(classSelect);
    composeContainer.appendChild(classField);

    // Öğrenci Seçimi
    const studentField = document.createElement("div");
    studentField.className = "compose-field";

    const studentLabel = document.createElement("label");
    studentLabel.textContent = "Öğrenci Seç:";
    studentField.appendChild(studentLabel);

    const studentSelect = document.createElement("select");
    studentSelect.id = "student-select";
    ["Tüm Öğrenciler", "Ali Veli", "Ayşe Fatma", "Mehmet Can"].forEach((optionText, index) => {
        const option = document.createElement("option");
        option.value = index === 0 ? "all" : `student-${index}`;
        option.textContent = optionText;
        studentSelect.appendChild(option);
    });
    studentField.appendChild(studentSelect);
    composeContainer.appendChild(studentField);

    // Mesaj Alanı
    const messageField = document.createElement("div");
    messageField.className = "compose-field";

    const messageLabel = document.createElement("label");
    messageLabel.textContent = "Mesajınız:";
    messageField.appendChild(messageLabel);

    (document.createElement("textarea")).id = "new-message-input";
    (document.createElement("textarea")).placeholder = "Mesajınızı yazın...";
    messageField.appendChild(document.createElement("textarea"));
    composeContainer.appendChild(messageField);

    // Gönder Butonu
    const sendButton = document.createElement("button");
    sendButton.id = "send-new-message";
    sendButton.className = "compose-send-button";
    sendButton.textContent = "Gönder";
    composeContainer.appendChild(sendButton);

    // Yeni Mesaj Alanını main-container'ın en üstüne ekle
    mainContainer.insertBefore(composeContainer, mainContainer.firstChild);

    // Gönder Butonu İşlevselliği
    sendButton.addEventListener("click", () => {
        const classSelected = classSelect.value;
        const studentSelected = studentSelect.value;
        const messageContent = (document.createElement("textarea")).value.trim();

        if (!messageContent) {
            alert("Lütfen bir mesaj girin!");
            return;
        }

        alert(`Mesaj gönderildi:\n\nSınıf: ${classSelected}\nÖğrenci: ${studentSelected}\nMesaj: ${messageContent}`);
        
        // Mesaj kutusunu temizle
        (document.createElement("textarea")).value = "";
    });

    // Mevcut mesaj kutusu kısmı
    const layoutContainer = document.createElement("div");
    layoutContainer.style.display = "flex";
    layoutContainer.style.height = "100%";

    // Mesaj listesi kısmı
    const messageListContainer = document.createElement("aside");
    messageListContainer.className = "message-list-container";
    messageListContainer.style.background = "#222";
    messageListContainer.style.color = "#fff";
    messageListContainer.style.width = "300px";
    messageListContainer.style.padding = "1rem";
    messageListContainer.style.overflowY = "auto";

    const messageListTitle = document.createElement("h3");
    messageListTitle.textContent = "Mesajlar";
    messageListTitle.style.borderBottom = "1px solid #444";
    messageListTitle.style.paddingBottom = "0.5rem";
    messageListTitle.style.marginBottom = "1rem";
    messageListContainer.appendChild(messageListTitle);

    const messageList = document.createElement("ul");
    messageList.style.listStyle = "none";
    messageList.style.padding = "0";

    const messageThreads = [
        { id: 1, title: "Erkan Hoca - 4 Mayıs TDL Etütü Hk.", isActive: true },
        { id: 2, title: "23 Nisan Tatili Duyurusu", isActive: false },
        { id: 3, title: "Sinem Hoca - 27 Nisan Deneme Sınavı", isActive: false },
    ];

    messageThreads.forEach((thread) => {
        const threadItem = document.createElement("li");
        threadItem.textContent = thread.title;
        threadItem.style.padding = "0.5rem";
        threadItem.style.cursor = "pointer";
        threadItem.style.background = thread.isActive ? "#444" : "transparent";
        threadItem.style.borderRadius = "4px";

        threadItem.addEventListener("click", () => {
            document.querySelectorAll(".message-list-container li").forEach((item) => {
                item.style.background = "transparent";
            });
            threadItem.style.background = "#444";

            chatHeader.innerHTML = `<h2>${thread.title}</h2>`;
            loadMessages(thread.id);
        });

        messageList.appendChild(threadItem);
    });

    messageListContainer.appendChild(messageList);

    // Sohbet kutusu
    const chatContainer = document.createElement("div");
    chatContainer.className = "chat-container";
    chatContainer.style.flex = "1";
    chatContainer.style.display = "flex";
    chatContainer.style.flexDirection = "column";

    const chatHeader = document.createElement("div");
    chatHeader.className = "chat-header";
    chatHeader.style.background = "#000";
    chatHeader.style.color = "#fff";
    chatHeader.style.padding = "1rem";
    chatHeader.style.textAlign = "center";
    chatHeader.innerHTML = `<h2>Mesaj Kutusu</h2>`;
    chatContainer.appendChild(chatHeader);

    const chatMessages = document.createElement("div");
    chatMessages.id = "chat-messages";
    chatMessages.style.flex = "1";
    chatMessages.style.padding = "1rem";
    chatMessages.style.overflowY = "auto";
    chatMessages.style.color = "#fff";
    chatContainer.appendChild(chatMessages);

    // Mesaj gönderme alanı
    const chatInput = document.createElement("div");
    chatInput.className = "chat-input";
    chatInput.style.display = "flex";
    chatInput.style.padding = "0.5rem";
    chatInput.style.background = "#222";

    const messageInput = document.createElement("textarea");
    (document.createElement("textarea")).id = "chat-message-input";
    (document.createElement("textarea")).placeholder = "Mesaj Yaz...";
    (document.createElement("textarea")).rows = 2;
    (document.createElement("textarea")).style.flex = "1";
    (document.createElement("textarea")).style.resize = "none";
    (document.createElement("textarea")).style.marginRight = "0.5rem";
    chatInput.appendChild(document.createElement("textarea"));

    const sendMessageButton = document.createElement("button");
    sendMessageButton.textContent = "Gönder";
    sendMessageButton.style.background = "#4a90e2";
    sendMessageButton.style.color = "#fff";
    sendMessageButton.style.border = "none";
    sendMessageButton.style.padding = "0.5rem 1rem";
    sendMessageButton.style.borderRadius = "5px";
    chatInput.appendChild(sendMessageButton);

    chatContainer.appendChild(chatInput);

    layoutContainer.appendChild(messageListContainer);
    layoutContainer.appendChild(chatContainer);
    mainContainer.appendChild(layoutContainer);

    // Gönder Butonu İşlevselliği
    sendMessageButton.addEventListener("click", () => {
        const messageText = (document.createElement("textarea")).value.trim();
        if (messageText) {
            const messageDiv = document.createElement("div");
            messageDiv.textContent = messageText;
            messageDiv.style.background = "#4a90e2";
            messageDiv.style.color = "#fff";
            messageDiv.style.padding = "0.5rem";
            messageDiv.style.margin = "0.5rem 0";
            chatMessages.appendChild(messageDiv);
            (document.createElement("textarea")).value = "";
        }
    });

    // Örnek mesajlar
    const messagesByThread = {
        1: [{ text: "4 Mayıs etütü iptal olmuştur.", sender: "instructor", initials: "EH" }],
        2: [{ text: "23 Nisan tatili nedeniyle ders yapılmayacak.", sender: "instructor", initials: "Y" }],
    };

    function loadMessages(threadId) {
        chatMessages.innerHTML = "";
        (messagesByThread[threadId] || []).forEach((msg) => {
            const messageDiv = document.createElement("div");
            messageDiv.textContent = msg.text;
            messageDiv.style.background = "#444";
            messageDiv.style.color = "#fff";
            messageDiv.style.padding = "0.5rem";
            messageDiv.style.margin = "0.5rem 0";
            chatMessages.appendChild(messageDiv);
        });
    }

    loadMessages(1);
});



