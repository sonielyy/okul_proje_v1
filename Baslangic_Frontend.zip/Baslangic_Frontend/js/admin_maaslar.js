// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* MAIN KISMI */

document.addEventListener("DOMContentLoaded", function() {
    const salaryData = [
        { id: 1, name: "Ahmet Yılmaz", role: "Öğretmen", department: "Matematik", salary: 25000 },
        { id: 2, name: "Mehmet Kaya", role: "Öğretmen", department: "Fizik", salary: 24000 },
        { id: 3, name: "Ayşe Demir", role: "Müdür Yardımcısı", department: "Yönetim", salary: 30000 },
        { id: 4, name: "Elif Çelik", role: "Öğretmen", department: "Türkçe", salary: 23500 },
        { id: 5, name: "Hakan Yıldız", role: "Sekreter", department: "İdari İşler", salary: 18000 }
    ];

    function renderTable(data) {
        const tableBody = document.getElementById("salary-table-body");
        tableBody.innerHTML = ""; // Önce içeriği temizle

        data.forEach((person) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${person.name}</td>
                <td>${person.role}</td>
                <td>${person.department}</td>
                <td>${person.salary.toLocaleString()} TL</td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Sayfa Yüklendiğinde Maaşları Göster
    renderTable(salaryData);

    // Arama Filtreleme
    document.getElementById("search-input").addEventListener("input", function(event) {
        const searchText = event.target.value.toLowerCase();
        const filteredData = salaryData.filter(person =>
            person.name.toLowerCase().includes(searchText) ||
            person.role.toLowerCase().includes(searchText) ||
            person.department.toLowerCase().includes(searchText)
        );
        renderTable(filteredData);
    });
});
