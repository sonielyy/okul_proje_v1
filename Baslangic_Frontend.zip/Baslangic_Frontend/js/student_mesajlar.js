// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* MESAJLAR KISMI */

document.addEventListener("DOMContentLoaded", () => {
    const mainContainer = document.getElementById("main-container");

    // Create main layout
    const layoutContainer = document.createElement("div");
    layoutContainer.style.display = "flex";
    layoutContainer.style.height = "100%";

    // Create the left-side panel (message list)
    const messageListContainer = document.createElement("aside");
    messageListContainer.className = "message-list-container";
    messageListContainer.style.background = "#222";
    messageListContainer.style.color = "#fff";
    messageListContainer.style.width = "300px";
    messageListContainer.style.padding = "1rem";
    messageListContainer.style.overflowY = "auto";

    const messageListTitle = document.createElement("h3");
    messageListTitle.textContent = "Mesajlar";
    messageListTitle.style.borderBottom = "1px solid #444";
    messageListTitle.style.paddingBottom = "0.5rem";
    messageListTitle.style.marginBottom = "1rem";
    messageListContainer.appendChild(messageListTitle);

    const messageList = document.createElement("ul");
    messageList.style.listStyle = "none";
    messageList.style.padding = "0";

    // Example message threads
    const messageThreads = [
        { id: 1, title: "Erkan Hoca - 4 Mayıs TDL Etütü Hk.", isActive: true },
        { id: 2, title: "23 Nisan Tatili Duyurusu", isActive: false },
        { id: 3, title: "Sinem Hoca - 27 Nisan Deneme Sınavı", isActive: false },
    ];

    messageThreads.forEach((thread) => {
        const threadItem = document.createElement("li");
        threadItem.textContent = thread.title;
        threadItem.style.padding = "0.5rem";
        threadItem.style.cursor = "pointer";
        threadItem.style.background = thread.isActive ? "#444" : "transparent";
        threadItem.style.borderRadius = "4px";
    
        threadItem.addEventListener("click", () => {
            // Set active state for the selected thread
            document.querySelectorAll(".message-list-container li").forEach((item) => {
                item.style.background = "transparent";
            });
            threadItem.style.background = "#444";
    
            // Update chat header title
            chatHeader.innerHTML = `<h2>${thread.title}</h2>`;
    
            // Load the messages for the selected thread
            loadMessages(thread.id);
        });
    
        messageList.appendChild(threadItem);
    });
    

    messageListContainer.appendChild(messageList);

    // Create the chat container
    const chatContainer = document.createElement("div");
    chatContainer.className = "chat-container";
    chatContainer.style.flex = "1";
    chatContainer.style.display = "flex";
    chatContainer.style.flexDirection = "column";
    chatContainer.style.background = "#121212";

    const chatHeader = document.createElement("div");
    chatHeader.className = "chat-header";
    chatHeader.style.background = "#000";
    chatHeader.style.color = "#fff";
    chatHeader.style.padding = "1rem";
    chatHeader.style.textAlign = "center";
    chatHeader.innerHTML = `<h2>Mesaj Kutusu</h2>`;
    chatContainer.appendChild(chatHeader);

    const chatMessages = document.createElement("div");
    chatMessages.id = "chat-messages";
    chatMessages.style.flex = "1";
    chatMessages.style.padding = "1rem";
    chatMessages.style.overflowY = "auto";
    chatMessages.style.color = "#fff";
    chatContainer.appendChild(chatMessages);

    const chatInput = document.createElement("div");
    chatInput.className = "chat-input";
    chatInput.style.display = "flex";
    chatInput.style.padding = "0.5rem";
    chatInput.style.background = "#222";

    const messageInput = document.createElement("textarea");
    messageInput.id = "message-input";
    messageInput.placeholder = "Mesaj Yaz...";
    messageInput.rows = 2;
    messageInput.style.flex = "1";
    messageInput.style.resize = "none";
    messageInput.style.marginRight = "0.5rem";
    chatInput.appendChild(messageInput);

    const sendButton = document.createElement("button");
    sendButton.id = "send-button";
    sendButton.textContent = "Gönder";
    sendButton.style.background = "#4a90e2";
    sendButton.style.color = "#fff";
    sendButton.style.border = "none";
    sendButton.style.padding = "0.5rem 1rem";
    sendButton.style.borderRadius = "5px";
    chatInput.appendChild(sendButton);

    chatContainer.appendChild(chatInput);

    layoutContainer.appendChild(messageListContainer);
    layoutContainer.appendChild(chatContainer);
    mainContainer.appendChild(layoutContainer);

    // Load initial messages
    const messagesByThread = {
        1: [
            { text: "Bir cenazeye katılmam gerektiğinden 4 Mayıs etütü iptal olmuştur.", sender: "instructor", initials: "EH" },
            { text: "Tamam hocam.", sender: "user", initials: "AA" },
        ],
        2: [
            { text: "23 Nisan resmi tatilinden dolayı bir ders olmayacaktır.", sender: "instructor", initials: "Y" },
            { text: "Hepinize iyi tatiller!", sender: "instructor", initials: "Y" }
        ],
        3: [
            { text: "27 Nisan günü YKS deneme sınavının 18. sini yapacağız, herkes hazır gelsin!", sender: "instructor", initials: "SH" },
            { text: "Hocam deneme A2'de mi yapılacak yoksa başka yerde mi?", sender: "user", initials: "BG" },
            { text: "Berkay deneme bu sefer A7'de yapılacak.", sender: "instructor", initials: "SH" },
            { text: "ben katılmayacağım hocam rahatsızlığımdan dolayı", sender: "user", initials: "MR" },
            { text: "Geçmiş olsun Melisa.", sender: "instructor", initials: "SH" },
        ],
    };

    function loadMessages(threadId) {
        chatMessages.innerHTML = ""; // Clear previous messages
        const threadMessages = messagesByThread[threadId] || [];
        threadMessages.forEach((msg) => {
            addMessage(msg.text, msg.sender, msg.initials);
        });
    }

    function addMessage(text, sender = "user", initials = "U") {
        const messageDiv = document.createElement("div");
        messageDiv.className = `chat-message ${sender}`;
        messageDiv.style.display = "flex";
        messageDiv.style.alignItems = "center";
        messageDiv.style.marginBottom = "0.5rem";

        const profilePic = document.createElement("div");
        profilePic.textContent = initials;
        profilePic.style.width = "30px";
        profilePic.style.height = "30px";
        profilePic.style.borderRadius = "50%";
        profilePic.style.display = "flex";
        profilePic.style.justifyContent = "center";
        profilePic.style.alignItems = "center";
        profilePic.style.color = "#fff";
        profilePic.style.background = sender === "user" ? "#4a90e2" : "#444";
        profilePic.style.marginRight = "0.5rem";

        const messageText = document.createElement("div");
        messageText.textContent = text;
        messageText.style.padding = "0.5rem";
        messageText.style.borderRadius = "5px";
        messageText.style.background = sender === "user" ? "#4a90e2" : "#444";
        messageText.style.color = "#fff";
        messageText.style.flex = "1";

        messageDiv.appendChild(profilePic);
        messageDiv.appendChild(messageText);
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight; // Scroll to the bottom
    }

    sendButton.addEventListener("click", () => {
        const messageText = messageInput.value.trim();
        if (messageText) {
            addMessage(messageText, "user", "A");
            messageInput.value = "";
        }
    });

    // Load default thread
    loadMessages(1);
});

