// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* MAIN KISMI */

document.addEventListener("DOMContentLoaded", function () {
    const expensesTable = document.getElementById("expenses-table tbody");
    const addExpenseForm = document.getElementById("add-expense-form");
    const categoryFilter = document.getElementById("category-filter");

    // Mevcut giderleri yükle (LocalStorage)
    function loadExpenses() {
        expensesTable.innerHTML = ""; // Önce temizle
        let expenses = JSON.parse(localStorage.getItem("expenses")) || [];

        expenses.forEach((expense, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${expense.category}</td>
                <td>${expense.amount} TL</td>
                <td>${expense.date}</td>
                <td>${expense.description}</td>
                <td><button class="delete-btn" data-index="${index}">🗑️</button></td>
            `;
            expensesTable.appendChild(row);
        });
    }

    // Yeni gider ekleme işlemi
    addExpenseForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const category = document.getElementById("expense-category").value;
        const amount = document.getElementById("expense-amount").value;
        const date = document.getElementById("expense-date").value;
        const description = document.getElementById("expense-description").value;

        if (!category || !amount || !date || !description) {
            alert("Lütfen tüm alanları doldurun!");
            return;
        }

        let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
        expenses.push({ category, amount, date, description });
        localStorage.setItem("expenses", JSON.stringify(expenses));

        addExpenseForm.reset();
        loadExpenses();
    });

    // Gider Silme
    expensesTable.addEventListener("click", function (e) {
        if (e.target.classList.contains("delete-btn")) {
            const index = e.target.getAttribute("data-index");
            let expenses = JSON.parse(localStorage.getItem("expenses")) || [];
            expenses.splice(index, 1);
            localStorage.setItem("expenses", JSON.stringify(expenses));
            loadExpenses();
        }
    });

    // Kategoriye göre filtreleme
    categoryFilter.addEventListener("change", function () {
        let selectedCategory = categoryFilter.value;
        let expenses = JSON.parse(localStorage.getItem("expenses")) || [];

        if (selectedCategory !== "all") {
            expenses = expenses.filter(expense => expense.category === selectedCategory);
        }

        expensesTable.innerHTML = "";
        expenses.forEach((expense, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${expense.category}</td>
                <td>${expense.amount} TL</td>
                <td>${expense.date}</td>
                <td>${expense.description}</td>
                <td><button class="delete-btn" data-index="${index}">🗑️</button></td>
            `;
            expensesTable.appendChild(row);
        });
    });

    loadExpenses(); // Sayfa açıldığında giderleri yükle
});
