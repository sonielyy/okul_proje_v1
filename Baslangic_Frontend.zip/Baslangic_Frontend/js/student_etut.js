// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});



/* ETÜT KISMI */

document.addEventListener("DOMContentLoaded", () => {
    const mainContent = document.getElementById("main-content");

    // Etüt Panelini Oluştur
    const etutPanel = document.createElement("div");
    etutPanel.className = "etut-panel";

    const etutTitle = document.createElement("h2");
    etutTitle.textContent = "Etütler";
    etutPanel.appendChild(etutTitle);

    const etutList = document.createElement("div");
    etutList.className = "etut-list";
    etutPanel.appendChild(etutList);

    mainContent.appendChild(etutPanel);

    // Örnek Etüt Verileri
    const etutData = [
        { id: 1, title: "Matematik - Fonksiyonlar", teacher: "Ahmet Hoca", time: "10:00 - 11:30" },
        { id: 2, title: "Fizik - Kuvvet ve Hareket", teacher: "Fatma Hoca", time: "12:00 - 13:30" },
    ];

    // Etütleri Listele
    etutData.forEach(etut => {
        const etutItem = document.createElement("div");
        etutItem.className = "etut-item";

        etutItem.innerHTML = `
            <h3>${etut.title}</h3>
            <p><strong>Hoca:</strong> ${etut.teacher}</p>
            <p><strong>Saat:</strong> ${etut.time}</p>
            <button class="view-details-btn" data-id="${etut.id}">Detayları Gör</button>
        `;

        etutList.appendChild(etutItem);
    });

    // Detayları Görme
    document.addEventListener("click", (event) => {
        if (event.target.classList.contains("view-details-btn")) {
            const etutId = event.target.dataset.id;
            const etut = etutData.find(e => e.id == etutId);

            if (etut) showEtutDetails(etut);
        }
    });

    // Detay Modalı
    function showEtutDetails(etut) {
        const modal = document.createElement("div");
        modal.className = "modal";
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close-btn">&times;</span>
                <h2>${etut.title}</h2>
                <p><strong>Hoca:</strong> ${etut.teacher}</p>
                <p><strong>Saat:</strong> ${etut.time}</p>
                <button>Katılımı Onayla</button>
            </div>
        `;

        document.body.appendChild(modal);

        // Kapatma
        modal.querySelector(".close-btn").addEventListener("click", () => {
            modal.remove();
        });
    }
});
