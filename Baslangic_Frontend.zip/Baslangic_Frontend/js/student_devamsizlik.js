// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* MAIN KISMI */


document.addEventListener("DOMContentLoaded", function () {
    const attendanceData = [
        { date: "2025-01-01", status: "Geldi" },
        { date: "2025-01-02", status: "Gelmedi" },
        { date: "2025-01-03", status: "Geldi" },
        { date: "2025-01-04", status: "Geç" },
        { date: "2025-01-05", status: "Gelmedi" },
    ];

    const calendar = document.getElementById("calendar");

    // Mevcut tarihi al
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();

    // Ayın ilk ve son gününü al
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);

    // Takvimi oluştur
    for (let day = 1; day <= lastDay.getDate(); day++) {
        const currentDate = new Date(currentYear, currentMonth, day);
        const dateString = currentDate.toISOString().split("T")[0]; // YYYY-MM-DD formatı

        // Her gün için bir kutucuk oluştur
        const dayElement = document.createElement("div");
        dayElement.classList.add("calendar-day");

        // Devamsızlık durumunu bul
        const attendance = attendanceData.find((entry) => entry.date === dateString);
        if (attendance) {
            if (attendance.status === "Geldi") {
                dayElement.classList.add("present");
            } else if (attendance.status === "Gelmedi") {
                dayElement.classList.add("past");
            } else if (attendance.status === "Geç") {
                dayElement.classList.add("late");
            }
        } else if (currentDate > today) {
            dayElement.classList.add("future");
        } else {
            dayElement.classList.add("past");
        }

        // Tarihi ve durumu ekle
        dayElement.innerHTML = `
            <span>${day}</span>
            <small>${attendance ? attendance.status : "—"}</small>
        `;

        calendar.appendChild(dayElement);
    }
});

