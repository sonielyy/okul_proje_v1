// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* MAIN KISMI */


document.addEventListener("DOMContentLoaded", () => {
    // Örnek Kasa Verileri
    const transactions = [
        { date: "2025-01-01", description: "Okul Ücret Ödemesi", income: 5000, expense: 0 },
        { date: "2025-01-03", description: "Kitap Alımı", income: 0, expense: 1500 },
        { date: "2025-01-05", description: "Servis Ödemesi", income: 0, expense: 2000 },
        { date: "2025-01-07", description: "Bağış Geliri", income: 2500, expense: 0 },
    ];

    // Kasa Özeti ve İşlem Tablosunu Güncelleme
    const cashSummaryEl = document.getElementById("cash-summary");
    const transactionTableBody = document.querySelector("#transaction-table tbody");

    let totalIncome = 0;
    let totalExpense = 0;
    let balance = 0;

    // İşlemleri Tabloya Ekle
    transactions.forEach(transaction => {
        totalIncome += transaction.income;
        totalExpense += transaction.expense;
        balance = totalIncome - totalExpense;

        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${transaction.date}</td>
            <td>${transaction.description}</td>
            <td>${transaction.income > 0 ? `₺${transaction.income}` : "-"}</td>
            <td>${transaction.expense > 0 ? `₺${transaction.expense}` : "-"}</td>
            <td>₺${balance}</td>
        `;
        transactionTableBody.appendChild(row);
    });

    // Özeti Göster
    cashSummaryEl.innerHTML = `
        <div>
            <h3>Toplam Gelir</h3>
            <p>₺${totalIncome}</p>
        </div>
        <div>
            <h3>Toplam Gider</h3>
            <p>₺${totalExpense}</p>
        </div>
        <div>
            <h3>Bakiye</h3>
            <p>₺${balance}</p>
        </div>
    `;
});
