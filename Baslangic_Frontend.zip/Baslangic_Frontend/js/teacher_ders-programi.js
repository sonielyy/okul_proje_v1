// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* DERS PROGRAMI KISMI */

// Dinamik olarak bir ders ekleme
// Dinamik Tablo Oluşturucu
// Dinamik Ders Programı Tablosu
function createStylishSchedule(startHour, endHour, intervalMinutes, lectures) {
    const mainContainer = document.querySelector('main');

    // Ders Programı Wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'schedule-wrapper';

    // Günler ve Saatler için başlıklar
    const days = ['Saat', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];

    // Tablo Başlıkları
    const table = document.createElement('table');
    table.className = 'schedule-table';

    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    days.forEach(day => {
        const th = document.createElement('th');
        th.textContent = day;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Tablo Gövdesi
    const tbody = document.createElement('tbody');
    for (let hour = startHour; hour < endHour; hour++) {
        for (let minutes = 0; minutes < 60; minutes += intervalMinutes) {
            const timeSlot = `${String(hour).padStart(2, '0')}:${String(minutes).padStart(2, '0')} - ${String(hour).padStart(2, '0')}:${String(minutes + intervalMinutes).padStart(2, '0')}`;
            const row = document.createElement('tr');

            // Saat Hücresi
            const timeCell = document.createElement('td');
            timeCell.className = 'time-slot';
            timeCell.textContent = timeSlot;
            row.appendChild(timeCell);

            // Dersler için hücreler
            for (let day = 0; day < 6; day++) {
                const cell = document.createElement('td');
                cell.className = 'lecture-cell';
                row.appendChild(cell);
            }

            tbody.appendChild(row);
        }
    }
    table.appendChild(tbody);
    wrapper.appendChild(table);
    mainContainer.appendChild(wrapper);

    // Dersleri ekle
    fillStylishLectures(tbody, lectures, intervalMinutes);
}

function createLectureCell({ id, title, description, startTime, duration, homework = [], announcements = [], className = 'lecture-default' }) {
    const hasHomework = homework.length > 0;
    const hasAnnouncements = announcements.length > 0;

    return `
        <div class="lecture-block ${className}">
            <!-- Ders Başlığı -->
            <div class="lecture-name">
                <span>${title}</span>
                <span class="lecture-time">(${startTime} - ${duration} saat)</span>
            </div>

            <!-- Ders Açıklaması -->
            <div class="lecture-description">
                <span>${description}</span>
            </div>

            <!-- Ödevler Bölümü -->
            <div>
                <span class="lecture-section-title">Ödevler</span>
                <ul class="lecture-list homework-list">
                    ${hasHomework 
                        ? homework.map(hw => `<li>${hw}</li>`).join('') 
                        : '<span class="lecture-list-empty">Henüz ödev bulunmuyor.</span>'
                    }
                </ul>
                <button class="add-button" onclick="openHomeworkModal(${id})">+ Ödev Ekle</button>
            </div>

            <!-- Duyurular Bölümü -->
            <div>
                <span class="lecture-section-title">Ders Duyuruları</span>
                <ul class="lecture-list announcements-list">
                    ${hasAnnouncements 
                        ? announcements.map(ann => `<li>${ann}</li>`).join('') 
                        : '<span class="lecture-list-empty">Henüz duyuru bulunmuyor.</span>'
                    }
                </ul>
                <button class="add-button" onclick="openAnnouncementModal(${id})">+ Duyuru Ekle</button>
            </div>
        </div>
    `;
}




// Dersleri Stilize Etme
document.addEventListener('DOMContentLoaded', () => {
    createStylishSchedule(9, 18, 15, lectures);
});

function fillStylishLectures(tbody, lectures, intervalMinutes) {
    lectures.forEach(lecture => {
        const [startHour, startMinute] = lecture.startTime.split(':').map(Number);
        const totalSlots = Math.ceil(lecture.duration / (intervalMinutes / 60));

        const row = Array.from(tbody.querySelectorAll('tr')).find(r => {
            const timeSlot = r.querySelector('.time-slot').textContent.split(' - ')[0];
            const [rowHour, rowMinute] = timeSlot.split(':').map(Number);
            return rowHour === startHour && rowMinute === startMinute;
        });

        if (row) {
            const cell = row.querySelector(`td:nth-child(${lecture.day + 2})`);
            if (cell) {
                cell.rowSpan = totalSlots;
                cell.innerHTML = createLectureCell(lecture);
                cell.style.height = `${totalSlots * 60}px`;

                let nextRow = row.nextElementSibling;
                for (let i = 1; i < totalSlots; i++) {
                    if (nextRow) {
                        const nextCell = nextRow.querySelector(`td:nth-child(${lecture.day + 2})`);
                        if (nextCell) nextCell.remove();
                        nextRow = nextRow.nextElementSibling;
                    }
                }
            }
        }
    });
}



// Lise Ders Verileri
const lectures = [
    {
        id: 1,
        day: 0, 
        startTime: '09:15',
        duration: 2,
        title: 'Cebir 101',
        description: 'Temel cebir konuları.',
        homework: ['Problem seti 1'],
        announcements: ['Cuma günü sınav var'],
        className: 'lecture-math',
    },
    {
        id: 2,
        day: 1,
        startTime: '10:30',
        duration: 1.5,
        title: 'Tarih 101',
        description: 'Modern dünya üzerindeki etkiler.',
        homework: [],
        announcements: [],
        className: 'lecture-history',
    }
];



// Modal aç/kapat
function openHomeworkModal(lectureId) {
    showModal(`Ödev Ekle`, lectureId, 'homework');
}

function openAnnouncementModal(lectureId) {
    showModal(`Duyuru Ekle`, lectureId, 'announcement');
}

function showModal(title, lectureId, type) {
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    modalOverlay.onclick = () => document.body.removeChild(modalOverlay);

    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <h3>${title}</h3>
        <textarea id="modal-input" rows="4" placeholder="${type === 'homework' ? 'Yeni ödev girin...' : 'Yeni duyuru girin...'}"></textarea>
        <button onclick="saveModalInput('${type}', ${lectureId})">Kaydet</button>
        <button onclick="document.body.removeChild(document.querySelector('.modal-overlay'))">İptal</button>
    `;

    modalOverlay.appendChild(modal);
    document.body.appendChild(modalOverlay);
}

// Yeni ödev/duyuru kaydet
function saveModalInput(type, lectureId) {
    const inputValue = document.getElementById('modal-input').value.trim();
    if (!inputValue) {
        alert('Lütfen bir şeyler yazın!');
        return;
    }

    const lecture = lectures.find(l => l.id === lectureId);
    if (type === 'homework') {
        lecture.homework.push(inputValue);
    } else {
        lecture.announcements.push(inputValue);
    }

    // Ders programını yeniden oluştur
    updateSchedule();

    // Modalı kapat
    document.body.removeChild(document.querySelector('.modal-overlay'));
}

// Ders programını yeniden oluştur
function updateSchedule() {
    document.querySelector('main').innerHTML = '';
    createStylishSchedule(9, 18, 15, lectures);
}

// Derslerin ID'sini oluştur
lectures.forEach((lecture, index) => {
    lecture.id = index + 1;
});
