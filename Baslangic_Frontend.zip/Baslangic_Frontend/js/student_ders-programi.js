// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* DERS PROGRAMI KISMI */

// Dinamik olarak bir ders ekleme
// Dinamik Tablo Oluşturucu
// Dinamik Ders Programı Tablosu
function createStylishSchedule(startHour, endHour, intervalMinutes, lectures) {
    const mainContainer = document.querySelector('main');

    // Ders Programı Wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'schedule-wrapper';

    // Günler ve Saatler için başlıklar
    const days = ['Saat', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];

    // Tablo Başlıkları
    const table = document.createElement('table');
    table.className = 'schedule-table';

    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    days.forEach(day => {
        const th = document.createElement('th');
        th.textContent = day;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Tablo Gövdesi
    const tbody = document.createElement('tbody');
    for (let hour = startHour; hour < endHour; hour++) {
        for (let minutes = 0; minutes < 60; minutes += intervalMinutes) {
            const timeSlot = `${String(hour).padStart(2, '0')}:${String(minutes).padStart(2, '0')} - ${String(hour).padStart(2, '0')}:${String(minutes + intervalMinutes).padStart(2, '0')}`;
            const row = document.createElement('tr');

            // Saat Hücresi
            const timeCell = document.createElement('td');
            timeCell.className = 'time-slot';
            timeCell.textContent = timeSlot;
            row.appendChild(timeCell);

            // Dersler için hücreler
            for (let day = 0; day < 6; day++) {
                const cell = document.createElement('td');
                cell.className = 'lecture-cell';
                row.appendChild(cell);
            }

            tbody.appendChild(row);
        }
    }
    table.appendChild(tbody);
    wrapper.appendChild(table);
    mainContainer.appendChild(wrapper);

    // Dersleri ekle
    fillStylishLectures(tbody, lectures, intervalMinutes);
}

function createLectureCell({ title, description, startTime, duration, homework = [], announcements = [], className = 'lecture-default' }) {
    const hasHomework = homework.length > 0;
    const hasAnnouncements = announcements.length > 0;

    return `
        <div class="lecture-block ${className}">
            <div class="lecture-name">
                <span>${title}</span>
                <span class="lecture-time">(${startTime} - ${duration} saat)</span>
            </div>
            <div class="lecture-description">
                <span>${description}</span>
            </div>
            <div>
                <span class="lecture-section-title">Ödevler</span>
                <ul class="lecture-list">
                    ${hasHomework ? homework.map(hw => `<li>${hw}</li>`).join('') : '<span class="lecture-list-empty">Güncel bir bilgilendirme yok</span>'}
                </ul>
            </div>
            <div>
                <span class="lecture-section-title">Ders Duyuruları</span>
                <ul class="lecture-list">
                    ${hasAnnouncements ? announcements.map(ann => `<li>${ann}</li>`).join('') : '<span class="lecture-list-empty">Güncel bir bilgilendirme yok</span>'}
                </ul>
            </div>
        </div>
    `;
}



// Dersleri Stilize Etme
document.addEventListener('DOMContentLoaded', () => {
    createStylishSchedule(9, 18, 15, lectures);
});

function fillStylishLectures(tbody, lectures, intervalMinutes) {
    lectures.forEach(lecture => {
        const [startHour, startMinute] = lecture.startTime.split(':').map(Number);
        const totalSlots = Math.ceil(lecture.duration / (intervalMinutes / 60));

        const row = Array.from(tbody.querySelectorAll('tr')).find(r => {
            const timeSlot = r.querySelector('.time-slot').textContent.split(' - ')[0];
            const [rowHour, rowMinute] = timeSlot.split(':').map(Number);
            return rowHour === startHour && rowMinute === startMinute;
        });

        if (row) {
            const cell = row.querySelector(`td:nth-child(${lecture.day + 2})`);
            if (cell) {
                cell.rowSpan = totalSlots;
                cell.innerHTML = createLectureCell(lecture);
                cell.style.height = `${totalSlots * 60}px`;

                let nextRow = row.nextElementSibling;
                for (let i = 1; i < totalSlots; i++) {
                    if (nextRow) {
                        const nextCell = nextRow.querySelector(`td:nth-child(${lecture.day + 2})`);
                        if (nextCell) nextCell.remove();
                        nextRow = nextRow.nextElementSibling;
                    }
                }
            }
        }
    });
}



// Lise Ders Verileri
const lectures = [
    {
        day: 0, // Pazartesi
        startTime: '09:15',
        duration: 2, // 2 saat
        title: 'Cebir 101',
        description: 'Temel cebir konuları ve problemlerin çözümü.',
        homework: ['Problem seti 1', 'Ödev 2'],
        announcements: ['Cuma günü sınav var'],
        className: 'lecture-math', // Matematik dersi
    },
    {
        day: 1, // Salı
        startTime: '10:30',
        duration: 1.5, // 1.5 saat
        title: 'Tarih 101',
        description: 'Modern dünya üzerindeki etkiler.',
        homework: [],
        announcements: [],
        className: 'lecture-history', // Tarih dersi
    },
    {
        day: 2, // Çarşamba
        startTime: '12:00',
        duration: 1, // 1 saat
        title: 'Kimya',
        description: 'Kimyasal reaksiyonlar ve denklemler.',
        homework: ['Kimyasal denklemleri çöz'],
        announcements: ['Kimya laboratuvarı saat 15:00\'te açık'],
        className: 'lecture-chemistry', // Kimya dersi
    },
    {
        day: 4, // Cuma
        startTime: '14:15',
        duration: 2.5, // 2.5 saat
        title: 'Fizik',
        description: 'Hız, ivme ve hareket.',
        homework: [],
        announcements: ['Ders 15 dakika geç başlayacak'],
        className: 'lecture-physics', // Fizik dersi
    },
];

