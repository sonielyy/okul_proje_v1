// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});



/* ETÜT KISMI */

document.addEventListener("DOMContentLoaded", () => {
    const mainContent = document.getElementById("main-content");
    const etutList = document.getElementById("etut-list");

    // Örnek Etüt Verileri
    let etutData = [
        { id: 1, title: "Matematik - Fonksiyonlar", class: "10-A", time: "10:00 - 11:30", location: "101" },
        { id: 2, title: "Fizik - Kuvvet ve Hareket", class: "11-B", time: "12:00 - 13:30", location: "202" },
    ];

    // Etütleri Listele
    function renderEtutList() {
        etutList.innerHTML = ""; // Listeyi temizle
        etutData.forEach(etut => {
            const etutItem = document.createElement("div");
            etutItem.className = "etut-item";
            etutItem.innerHTML = `
                <h3>${etut.title}</h3>
                <p><strong>Sınıf:</strong> ${etut.class}</p>
                <p><strong>Saat:</strong> ${etut.time}</p>
                <p><strong>Yer:</strong> ${etut.location}</p>
            `;
            etutList.appendChild(etutItem);
        });
    }

    // Yeni Etüt Formunu Göster
    document.getElementById("new-etut-btn").addEventListener("click", () => {
        const form = document.createElement("form");
        form.className = "new-etut-form";
        form.innerHTML = `
            <input type="text" id="etut-title" placeholder="Etüt Başlığı" required>
            <input type="text" id="etut-class" placeholder="Sınıf (ör: 10-A)" required>
            <input type="text" id="etut-time" placeholder="Saat (ör: 10:00 - 11:30)" required>
            <input type="text" id="etut-location" placeholder="Yer (ör: 101)" required>
            <button type="submit">Etüt Ekle</button>
        `;

        // Form Submit Olayı
        form.addEventListener("submit", (event) => {
            event.preventDefault();

            const newEtut = {
                id: etutData.length + 1,
                title: document.getElementById("etut-title").value,
                class: document.getElementById("etut-class").value,
                time: document.getElementById("etut-time").value,
                location: document.getElementById("etut-location").value,
            };

            etutData.push(newEtut); // Yeni etüt ekle
            renderEtutList(); // Listeyi güncelle
            alert("Yeni etüt başarıyla eklendi!");
            form.remove(); // Formu kaldır
        });

        mainContent.appendChild(form);
    });

    // Sayfa yüklendiğinde etütleri göster
    renderEtutList();
});


