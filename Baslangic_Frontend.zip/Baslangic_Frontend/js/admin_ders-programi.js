// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* DERS PROGRAMI KISMI */
// ADMIN KISMI
function createAdminPanel() {
    const mainContainer = document.querySelector('main');

    // Yönetici Kontrol Alanı Wrapper
    const adminPanelWrapper = document.createElement('div');
    adminPanelWrapper.className = 'schedule-wrapper'; // Aynı stil kullanıldı
    adminPanelWrapper.style.marginBottom = '20px'; // Üst boşluk

    // Eğitim-Öğretim Seçenekleri
    const classSelect = document.createElement('select');
    classSelect.id = 'class-select';
    ['9. Sınıf', '10. Sınıf', '11. Sınıf', '12. Sınıf'].forEach(cls => {
        const option = document.createElement('option');
        option.value = cls;
        option.textContent = cls;
        classSelect.appendChild(option);
    });

    const termSelect = document.createElement('select');
    termSelect.id = 'term-select';
    ['1. Dönem', '2. Dönem'].forEach(term => {
        const option = document.createElement('option');
        option.value = term;
        option.textContent = term;
        termSelect.appendChild(option);
    });

    // "Ders Ekle" ve "Ders Kaldır" Butonları
    const addLectureButton = document.createElement('button');
    addLectureButton.textContent = 'Ders Ekle';
    addLectureButton.className = 'add-button';
    addLectureButton.onclick = openAddLectureModal; // Mevcut JS işlevi kullanıldı

    const removeLectureButton = document.createElement('button');
    removeLectureButton.textContent = 'Ders Kaldır';
    removeLectureButton.className = 'add-button';
    removeLectureButton.style.backgroundColor = '#e74c3c'; // Kırmızı buton
    removeLectureButton.onclick = openRemoveLectureModal; // Mevcut JS işlevi kullanıldı

    // Alanı Düzenleme
    adminPanelWrapper.innerHTML = `
        <div style="display: flex; align-items: center; gap: 15px; justify-content: space-between;">
            <div>
                <label for="class-select" style="margin-right: 10px;">Sınıf:</label>
            </div>
            ${classSelect.outerHTML}
            <div>
                <label for="term-select" style="margin-right: 10px;">Dönem:</label>
            </div>
            ${termSelect.outerHTML}
            <div style="display: flex; gap: 10px;">
                ${addLectureButton.outerHTML}
                ${removeLectureButton.outerHTML}
            </div>
        </div>
    `;

    // Main Container'a Ekleniyor
    mainContainer.prepend(adminPanelWrapper);
}
// Dinamik olarak bir ders ekleme
// Dinamik Tablo Oluşturucu
// Dinamik Ders Programı Tablosu
function createStylishSchedule(startHour, endHour, intervalMinutes, lectures) {
    const mainContainer = document.querySelector('main');

    // Ders Programı Wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'schedule-wrapper';

    // Günler ve Saatler için başlıklar
    const days = ['Saat', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];

    // Tablo Başlıkları
    const table = document.createElement('table');
    table.className = 'schedule-table';

    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    days.forEach(day => {
        const th = document.createElement('th');
        th.textContent = day;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Tablo Gövdesi
    const tbody = document.createElement('tbody');
    for (let hour = startHour; hour < endHour; hour++) {
        for (let minutes = 0; minutes < 60; minutes += intervalMinutes) {
            const timeSlot = `${String(hour).padStart(2, '0')}:${String(minutes).padStart(2, '0')} - ${String(hour).padStart(2, '0')}:${String(minutes + intervalMinutes).padStart(2, '0')}`;
            const row = document.createElement('tr');

            // Saat Hücresi
            const timeCell = document.createElement('td');
            timeCell.className = 'time-slot';
            timeCell.textContent = timeSlot;
            row.appendChild(timeCell);

            // Dersler için hücreler
            for (let day = 0; day < 6; day++) {
                const cell = document.createElement('td');
                cell.className = 'lecture-cell';
                row.appendChild(cell);
            }

            tbody.appendChild(row);
        }
    }
    table.appendChild(tbody);
    wrapper.appendChild(table);
    mainContainer.appendChild(wrapper);

    // Dersleri ekle
    fillStylishLectures(tbody, lectures, intervalMinutes);
}

function createLectureCell({ id, title, description, startTime, duration, homework = [], announcements = [], className = 'lecture-default' }) {
    const hasHomework = homework.length > 0;
    const hasAnnouncements = announcements.length > 0;

    return `
        <div class="lecture-block ${className}">
            <!-- Ders Başlığı -->
            <div class="lecture-name">
                <span>${title}</span>
                <span class="lecture-time">(${startTime} - ${duration} saat)</span>
            </div>

            <!-- Ders Açıklaması -->
            <div class="lecture-description">
                <span>${description}</span>
            </div>

            <!-- Ödevler Bölümü -->
            <div>
                <span class="lecture-section-title">Ödevler</span>
                <ul class="lecture-list homework-list">
                    ${hasHomework 
                        ? homework.map(hw => `<li>${hw}</li>`).join('') 
                        : '<span class="lecture-list-empty">Henüz ödev bulunmuyor.</span>'
                    }
                </ul>
                <button class="add-button" onclick="openHomeworkModal(${id})">+ Ödev Ekle</button>
            </div>

            <!-- Duyurular Bölümü -->
            <div>
                <span class="lecture-section-title">Ders Duyuruları</span>
                <ul class="lecture-list announcements-list">
                    ${hasAnnouncements 
                        ? announcements.map(ann => `<li>${ann}</li>`).join('') 
                        : '<span class="lecture-list-empty">Henüz duyuru bulunmuyor.</span>'
                    }
                </ul>
                <button class="add-button" onclick="openAnnouncementModal(${id})">+ Duyuru Ekle</button>
            </div>
        </div>
    `;
}




// Dersleri Stilize Etme
// Sayfa yüklendiğinde admin paneli oluştur
document.addEventListener('DOMContentLoaded', () => {
    createAdminPanel();
    createStylishSchedule(9, 18, 15, lectures);
});



function fillStylishLectures(tbody, lectures, intervalMinutes) {
    lectures.forEach(lecture => {
        const [startHour, startMinute] = lecture.startTime.split(':').map(Number);
        const totalSlots = Math.ceil(lecture.duration / (intervalMinutes / 60));

        const row = Array.from(tbody.querySelectorAll('tr')).find(r => {
            const timeSlot = r.querySelector('.time-slot').textContent.split(' - ')[0];
            const [rowHour, rowMinute] = timeSlot.split(':').map(Number);
            return rowHour === startHour && rowMinute === startMinute;
        });

        if (row) {
            const cell = row.querySelector(`td:nth-child(${lecture.day + 2})`);
            if (cell) {
                cell.rowSpan = totalSlots;
                cell.innerHTML = createLectureCell(lecture);
                cell.style.height = `${totalSlots * 60}px`;

                let nextRow = row.nextElementSibling;
                for (let i = 1; i < totalSlots; i++) {
                    if (nextRow) {
                        const nextCell = nextRow.querySelector(`td:nth-child(${lecture.day + 2})`);
                        if (nextCell) nextCell.remove();
                        nextRow = nextRow.nextElementSibling;
                    }
                }
            }
        }
    });
}



// Lise Ders Verileri
const lectures = [
    {
        id: 1,
        day: 0, 
        startTime: '09:15',
        duration: 2,
        title: 'Cebir 101',
        description: 'Temel cebir konuları.',
        homework: ['Problem seti 1'],
        announcements: ['Cuma günü sınav var'],
        className: 'lecture-math',
    },
    {
        id: 2,
        day: 1,
        startTime: '10:30',
        duration: 1.5,
        title: 'Tarih 101',
        description: 'Modern dünya üzerindeki etkiler.',
        homework: [],
        announcements: [],
        className: 'lecture-history',
    }
];



// Modal aç/kapat
function openHomeworkModal(lectureId) {
    showModal(`Ödev Ekle`, lectureId, 'homework');
}

function openAnnouncementModal(lectureId) {
    showModal(`Duyuru Ekle`, lectureId, 'announcement');
}

function showModal(title, lectureId, type) {
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    modalOverlay.onclick = () => document.body.removeChild(modalOverlay);

    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <h3>${title}</h3>
        <textarea id="modal-input" rows="4" placeholder="${type === 'homework' ? 'Yeni ödev girin...' : 'Yeni duyuru girin...'}"></textarea>
        <button onclick="saveModalInput('${type}', ${lectureId})">Kaydet</button>
        <button onclick="document.body.removeChild(document.querySelector('.modal-overlay'))">İptal</button>
    `;

    modalOverlay.appendChild(modal);
    document.body.appendChild(modalOverlay);
}

// Yeni ödev/duyuru kaydet
function saveModalInput(type, lectureId) {
    const inputValue = document.getElementById('modal-input').value.trim();
    if (!inputValue) {
        alert('Lütfen bir şeyler yazın!');
        return;
    }

    const lecture = lectures.find(l => l.id === lectureId);
    if (type === 'homework') {
        lecture.homework.push(inputValue);
    } else {
        lecture.announcements.push(inputValue);
    }

    // Ders programını yeniden oluştur
    updateSchedule();

    // Modalı kapat
    document.body.removeChild(document.querySelector('.modal-overlay'));
}

// Ders programını yeniden oluştur
function updateSchedule() {
    document.querySelector('main').innerHTML = '';
    createStylishSchedule(9, 18, 15, lectures);
}

// Derslerin ID'sini oluştur
lectures.forEach((lecture, index) => {
    lecture.id = index + 1;
});


// ÜST PANEL 
function updateScheduleByClassAndTerm() {
    const selectedClass = document.getElementById("class-select").value;
    const selectedTerm = document.getElementById("term-select").value;

    const filteredLectures = lectures.filter(
        (lecture) => lecture.class === selectedClass && lecture.term === selectedTerm
    );

    updateSchedule(filteredLectures);
}

function openAddLectureModal() {
    showModal("Ders Ekle", null, "lecture-add");
}

function saveModalInput(type, lectureId) {
    const inputValue = document.getElementById("modal-input").value.trim();
    if (!inputValue) {
        alert("Lütfen bir şeyler yazın!");
        return;
    }

    if (type === "lecture-add") {
        const selectedClass = document.getElementById("class-select").value;
        const selectedTerm = document.getElementById("term-select").value;
        const newLecture = {
            id: lectures.length + 1,
            day: 0, // Varsayılan: Pazartesi
            startTime: "09:00", // Varsayılan saat
            duration: 1, // Varsayılan süre
            title: inputValue,
            description: "Yeni Eklenen Ders",
            class: selectedClass,
            term: selectedTerm,
            homework: [],
            announcements: [],
            className: "lecture-default",
        };
        lectures.push(newLecture);
        updateScheduleByClassAndTerm();
    }
}

function openRemoveLectureModal() {
    const selectedClass = document.getElementById("class-select").value;
    const selectedTerm = document.getElementById("term-select").value;

    const classLectures = lectures.filter(
        (lecture) => lecture.class === selectedClass && lecture.term === selectedTerm
    );

    const modalContent = classLectures
        .map(
            (lecture) => `
            <div>
                <input type="checkbox" id="lecture-${lecture.id}" value="${lecture.id}">
                <label for="lecture-${lecture.id}">${lecture.title} (${lecture.startTime})</label>
            </div>
        `
        )
        .join("");

    const modal = document.createElement("div");
    modal.className = "modal";
    modal.innerHTML = `
        <h3>Ders Kaldır</h3>
        <div>${modalContent}</div>
        <button onclick="removeSelectedLectures()">Seçili Dersleri Kaldır</button>
        <button onclick="document.body.removeChild(document.querySelector('.modal-overlay'))">İptal</button>
    `;
    document.body.appendChild(modal);
}

function removeSelectedLectures() {
    const selectedClass = document.getElementById("class-select").value;
    const selectedTerm = document.getElementById("term-select").value;

    const checkboxes = document.querySelectorAll("input[type='checkbox']:checked");
    const idsToRemove = Array.from(checkboxes).map((checkbox) => parseInt(checkbox.value));

    lectures = lectures.filter(
        (lecture) => !idsToRemove.includes(lecture.id) || lecture.class !== selectedClass || lecture.term !== selectedTerm
    );

    updateScheduleByClassAndTerm();
    document.body.removeChild(document.querySelector(".modal-overlay"));
}
