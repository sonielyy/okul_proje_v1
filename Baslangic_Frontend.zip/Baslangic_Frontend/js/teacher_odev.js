// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});



/* ODEV KISMI */

document.addEventListener("DOMContentLoaded", () => {
    const assignmentsList = document.getElementById("assignments-list");
    const addAssignmentBtn = document.getElementById("add-assignment-btn");

    const assignments = [
        { id: 1, class: "10-A", subject: "Matematik", title: "Türev Soruları" },
        { id: 2, class: "11-B", subject: "Fizik", title: "Hareket Problemleri" },
    ];

    // Ödevleri Listele
    const renderAssignments = () => {
        assignmentsList.innerHTML = "";
        assignments.forEach((assignment) => {
            const item = document.createElement("div");
            item.className = "assignment-item";
            item.innerHTML = `
                <h3>${assignment.title}</h3>
                <p><strong>Sınıf:</strong> ${assignment.class}</p>
                <p><strong>Ders:</strong> ${assignment.subject}</p>
            `;
            assignmentsList.appendChild(item);
        });
    };

    // Ödev Ekle Modalı Aç
    addAssignmentBtn.addEventListener("click", () => {
        const modal = document.createElement("div");
        modal.className = "modal";
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close-btn">&times;</span>
                <h2>Yeni Ödev Ekle</h2>
                <input type="text" id="class" placeholder="Sınıf (ör. 10-A)">
                <input type="text" id="subject" placeholder="Ders (ör. Matematik)">
                <input type="text" id="title" placeholder="Ödev Başlığı">
                <textarea id="description" placeholder="Ödev Açıklaması"></textarea>
                <input type="file" id="file-upload">
                <button id="submit-assignment-btn">Ekle</button>
            </div>
        `;

        document.body.appendChild(modal);

        // Modal Kapat
        modal.querySelector(".close-btn").addEventListener("click", () => {
            modal.remove();
        });

        // Yeni Ödev Ekleme
        modal.querySelector("#submit-assignment-btn").addEventListener("click", () => {
            const newAssignment = {
                id: assignments.length + 1,
                class: document.getElementById("class").value,
                subject: document.getElementById("subject").value,
                title: document.getElementById("title").value,
            };
            assignments.push(newAssignment);
            renderAssignments();
            modal.remove();
        });
    });

    renderAssignments();
});

