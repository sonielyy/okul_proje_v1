// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* DERS NOTLARI JS */


document.addEventListener("DOMContentLoaded", function () {
    const grades = [
        { subject: "Fen", exam1: 80, exam2: 90, council: 88 },
        { subject: "Kimya", exam1: 85, exam2: 87, council: 86 },
        { subject: "Tarih", exam1: 78, exam2: 84, council: 80 },
        { subject: "Türk Dili ve Edebiyatı", exam1: 88, exam2: 92, council: 90 },
        { subject: "Matematik", exam1: 95, exam2: 98, council: 96 },
    ];

    const tbody = document.querySelector("#grades-table tbody");

    grades.forEach((grade) => {
        const average = ((grade.exam1 + grade.exam2) / 2).toFixed(2);
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${grade.subject}</td>
            <td>${grade.exam1}</td>
            <td>${grade.exam2}</td>
            <td>${average}</td>
            <td>${grade.council}</td>
        `;

        tbody.appendChild(row);
    });
});


function saveCouncilGrade(index) {
    const inputField = document.querySelector(`#input-council-${index}`);
    const value = inputField.value;

    if (value < 0 || value > 100 || value === "") {
        alert("Lütfen geçerli bir not giriniz (0-100 arası).");
        return;
    }

    alert(`Kanaat notu kaydedildi: ${value}`);
}
