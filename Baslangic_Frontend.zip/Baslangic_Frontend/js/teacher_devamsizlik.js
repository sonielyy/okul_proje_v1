// Giriş Formu İşleme
document.getElementById("login-form")?.addEventListener("submit", function(event) {
    event.preventDefault();

    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;

    alert(`Hoş geldiniz ${username}! (${role} olarak giriş yaptınız.)`);
    // Burada role göre bir yönlendirme yapılabilir
    // Örneğin:
    // if (role === 'student') window.location.href = 'student/dashboard.html';
});


function navigateTo(section) {
    alert(`${section} bölümüne yönlendiriliyorsunuz...`);
    // Gerçek yönlendirme: window.location.href = `/${section}`;
}


function toggleSubmenu(menuId) {
    const menu = document.getElementById(menuId);

    if (menu.style.maxHeight) {
        // Menü zaten açık, kapat
        menu.style.maxHeight = null;
    } else {
        // Tüm menüleri kapat
        const allSubmenus = document.querySelectorAll('.submenu');
        allSubmenus.forEach(submenu => submenu.style.maxHeight = null);

        // Seçilen menüyü aç
        menu.style.maxHeight = menu.scrollHeight + "px";
    }
}


// Kullanıcı durumuna göre sağ üst menüyü düzenleme
document.addEventListener("DOMContentLoaded", () => {
    const userStatus = document.getElementById("user-status");
    const isLoggedIn = false; // Giriş durumunu burada kontrol edin (ör. bir API ile)

    if (isLoggedIn) {
        userStatus.innerHTML = `
            <img src="assets/user-avatar-icon.png" alt="Kullanıcı" class="action-icon">
            <span>Ad Soyad</span>
        `;
    } else {
        userStatus.innerHTML = `
            <img src="assets/login-icon.png" alt="Giriş Yap" class="action-icon">
            <span>Giriş Yap</span>
        `;
    }
});


document.addEventListener("click", (event) => {
    // Tıklanan elemanı al
    const target = event.target;

    // Tüm dropdown menüleri kontrol et
    document.querySelectorAll(".dropdown-menu").forEach(menu => {
        const parentItem = menu.closest(".action-item");
        
        if (parentItem.contains(target)) {
            // Eğer tıklanan element parent item'e aitse, menüyü açık bırak
            menu.style.display = "flex";
        } else {
            // Aksi halde menüyü kapat
            menu.style.display = "none";
        }
    });
});


/* MAIN KISMI */


document.addEventListener("DOMContentLoaded", function () {
    const attendanceData = {
        "101": [
            { student: "Ece Demir", date: "2025-01-15", status: "Gelmedi" },
            { student: "Kerem Kaya", date: "2025-01-15", status: "Gelmedi" },
            { student: "Ece Demir", date: "2025-01-20", status: "Gelmedi" }
        ],
        "102": [
            { student: "Kerem Kaya", date: "2025-01-18", status: "Gelmedi" }
        ]
    };
    const studentsPerClass = {
        "101": ["Ahmet", "Ayşe", "Mehmet"],
        "102": ["Ali", "Zeynep", "Fatma"],
        "103": ["Can", "Elif", "Eren"]
    };

    const classDropdown = document.getElementById("class");
    const studentDropdown = document.getElementById("student");
    const dateInput = document.getElementById("date");
    const calendar = document.getElementById("calendar");

    // Sınıf değiştiğinde öğrenci listesini güncelle
    classDropdown.addEventListener("change", function () {
        const selectedClass = classDropdown.value;
        const students = studentsPerClass[selectedClass];

        studentDropdown.innerHTML = ""; // Eski öğrencileri temizle
        students.forEach(student => {
            const option = document.createElement("option");
            option.value = student;
            option.textContent = student;
            studentDropdown.appendChild(option);
        });

        renderCalendar(selectedClass);
    });

    // Devamsızlık ekle
    document.getElementById("mark-absent").addEventListener("click", function () {
        const selectedClass = classDropdown.value;
        const selectedStudent = studentDropdown.value;
        const selectedDate = dateInput.value;

        if (!selectedClass || !selectedStudent || !selectedDate) {
            alert("Lütfen tüm alanları doldurun!");
            return;
        }

        // Devamsızlık kaydını ekle
        if (!attendanceData[selectedClass]) {
            attendanceData[selectedClass] = [];
        }
        attendanceData[selectedClass].push({
            student: selectedStudent,
            date: selectedDate,
            status: "Gelmedi"
        });

        alert(`${selectedStudent}, ${selectedDate} tarihinde devamsız olarak işaretlendi.`);
        renderCalendar(selectedClass);
    });

    // Takvimi güncelle
    function renderCalendar(classId) {
        calendar.innerHTML = ""; // Takvimi temizle
        const today = new Date();
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        const lastDay = new Date(currentYear, currentMonth + 1, 0).getDate();

        for (let day = 1; day <= lastDay; day++) {
            const date = new Date(currentYear, currentMonth, day).toISOString().split("T")[0];
            const dayElement = document.createElement("div");
            dayElement.classList.add("calendar-day");
            dayElement.innerHTML = `<span>${day}</span><small>—</small>`;

            // Devamsızlık kontrolü
            const classAttendance = attendanceData[classId] || [];
            const absentStudents = classAttendance
                .filter(entry => entry.date === date)
                .map(entry => entry.student);

            if (absentStudents.length > 0) {
                dayElement.classList.add("past");
                dayElement.innerHTML = `
                    <span>${day}</span>
                    <small>${absentStudents.join(", ")}</small>
                `;
            }

            calendar.appendChild(dayElement);
        }
    }

    // Varsayılan sınıfı yükle
    classDropdown.dispatchEvent(new Event("change"));
});


